﻿namespace ShippingService.Models
{
    public class ShippingServiceData
    {
    public int Id { get; set; }
    public string Name { get; set; }
    }
}

﻿namespace ProductmangementSystem.Models
{
    public class ShippingModel
    {

        public int Id { get; set; }

        public string Method { get; set; } // e.g., "Standard", "Express", "Overnight"

        public decimal Cost { get; set; } // e.g., 49.99

        public string Destination { get; set; } // e.g., "Chennai, India"

        public DateTime EstimatedDeliveryDate { get; set; }

        public string TrackingNumber { get; set; }

        public string Status { get; set; } // e.g., "Pending", "Shipped", "Delivered"

    }
}

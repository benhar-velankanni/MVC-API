﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using ProductmangementSystem.Models;
using System.Text.Json;

namespace ProductmangementSystem.Controllers
{
    public class ShippingController : Controller
    {
        private readonly HttpClient _httpClient;

        public ShippingController(IHttpClientFactory httpClientFactory)
        {
            _httpClient = httpClientFactory.CreateClient();
        }


      
        public async Task<IActionResult> Index()
        {
            var response = await _httpClient.GetAsync("https://localhost:7273/api/ShippingService");
            var content = await response.Content.ReadAsStringAsync();

            var shippingDetailsList = JsonConvert.DeserializeObject<List<ShippingModel>>(content);
            //var shippingDetails = shippingDetailsList?.FirstOrDefault();

            return View(shippingDetailsList);
        }

        [HttpGet]
        public IActionResult Create()
        {
            return View(new ShippingModel());
        }


        [HttpPost]
        public async Task<IActionResult> Create(ShippingModel model)
        {
            var response = await _httpClient.PostAsJsonAsync("https://localhost:7273/api/ShippingService", model);
            var result = await response.Content.ReadAsStringAsync();
            ViewBag.Message = result;
            return View();
        }


        [HttpGet]
        public async Task<IActionResult> Edit(int id)
        {
            var response = await _httpClient.GetAsync($"https://localhost:7273/api/ShippingService/{id}");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                var shippingModel = JsonConvert.DeserializeObject<ShippingModel>(content);
                return View(shippingModel);
            }

            return NotFound();
        }


        [HttpPost]
        public async Task<IActionResult> Edit(ShippingModel model)
        {
            var response = await _httpClient.PutAsJsonAsync($"https://localhost:7273/api/ShippingService/{model.Id}", model);
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            ViewBag.Message = "Update failed.";
            return View(model);
        }

        [HttpGet]
        public async Task<IActionResult> Delete(int id)
        {
            var response = await _httpClient.GetAsync($"https://localhost:7273/api/ShippingService/{id}");
            if (response.IsSuccessStatusCode)
            {
                var content = await response.Content.ReadAsStringAsync();
                var shippingModel = JsonConvert.DeserializeObject<ShippingModel>(content);
                return View(shippingModel);
            }

            return NotFound();
        }

        [HttpPost, ActionName("Delete")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"https://localhost:7273/api/ShippingService/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction("Index");
            }

            ViewBag.Message = "Delete failed.";
            return RedirectToAction("Delete", new { id });
        }


    }
}

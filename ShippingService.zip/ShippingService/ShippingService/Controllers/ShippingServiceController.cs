﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ShippingService.Data;
using ShippingService.Models;
using System;

namespace ShippingService.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ShippingServiceController : ControllerBase
    {
        private readonly AppDbContext _context;

        public ShippingServiceController(AppDbContext context)
        {
            _context = context;
        }        
        //
        [HttpGet]
        public async Task<IActionResult> GetAll()
        {
            var shipments = await _context.Shipments.ToListAsync();
            return Ok(shipments);
            }

        [HttpGet("{id}")]
        public async Task<IActionResult> Get(int id)
        {
            var shipment = await _context.Shipments.FindAsync(id);
            if (shipment == null) return NotFound();
            return Ok(shipment);
        }

        [HttpPost]
        public async Task<IActionResult> Create([FromBody] Shipment shipment)
            {
            _context.Shipments.Add(shipment);
            await _context.SaveChangesAsync();
            return CreatedAtAction(nameof(Get), new { id = shipment.Id }, shipment);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> Update(int id, [FromBody] Shipment updated)
        {
            var shipment = await _context.Shipments.FindAsync(id);
            if (shipment == null) return NotFound();

            shipment.Method = updated.Method;
            shipment.Cost = updated.Cost;
            shipment.Destination = updated.Destination;
            shipment.EstimatedDeliveryDate = updated.EstimatedDeliveryDate;
            shipment.TrackingNumber = updated.TrackingNumber;
            shipment.Status = updated.Status;
            await _context.SaveChangesAsync();
            return NoContent();
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> Delete(int id)
        {
            var shipment = await _context.Shipments.FindAsync(id);
            if (shipment == null) return NotFound();

            _context.Shipments.Remove(shipment);
            await _context.SaveChangesAsync();
            return NoContent();
        }

    }
}

﻿using Microsoft.EntityFrameworkCore;
using ShippingService.Models;

namespace ShippingService.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<ShippingServiceData> Items { get; set; }
        public DbSet<Shipment> Shipments { get; set; }
    }

}
